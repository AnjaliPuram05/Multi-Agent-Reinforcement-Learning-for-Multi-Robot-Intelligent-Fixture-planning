import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.animation as animation
import final
# Define grid size
grid_size = 10
num_fixtures = 5  # Total fixtures (3 constant, 2 working)

# Define bus parts and their positions in 3D space
bus_parts = {
    "door": (5, 2, 1),  # Door position
    "handle": (5, 2.5, 1.5)  # Handle position on the door
}

# Define starting positions for each fixture
start_positions = {
    0: (0, 0, 0),  # Fixture 1 starts here (constant)
    1: (0, 10, 0),  # Fixture 2 starts here (constant)
    2: (10, 0, 0),  # Fixture 3 starts here (constant)
    3: (10, 10, 0),  # Fixture 4 starts here (working)
    4: (5, 5, 5)  # Fixture 5 starts here (working)
}

# Define paths for the working fixtures to fix the bus parts
fixture_paths = {
    3: [start_positions[3], bus_parts["door"]],  # Fixture 4 fixes the door
    4: [start_positions[4], bus_parts["handle"]]  # Fixture 5 fixes the handle
}

# Function to create a full 3D bus model with a door and handle
def create_full_bus(ax):
    # Bus body (a rectangular cuboid)
    x = np.linspace(2, 8, 10)
    y = np.linspace(3, 7, 10)
    z = np.linspace(0, 2, 10)
    X, Y = np.meshgrid(x, y)
    Z = np.zeros_like(X)
    ax.plot_surface(X, Y, Z, color='blue', alpha=0.6, label="Bus Body")

    # Bus roof (a smaller rectangular cuboid)
    x_roof = np.linspace(3, 7, 10)
    y_roof = np.linspace(4, 6, 10)
    z_roof = np.linspace(2, 3, 10)
    X_roof, Y_roof = np.meshgrid(x_roof, y_roof)
    Z_roof = np.full_like(X_roof, 2)
    ax.plot_surface(X_roof, Y_roof, Z_roof, color='gray', alpha=0.6, label="Bus Roof")

    # Bus door (a rectangular cuboid)
    x_door = np.linspace(4, 6, 10)
    y_door = np.linspace(2, 2.5, 10)
    z_door = np.linspace(0, 2, 10)
    X_door, Y_door = np.meshgrid(x_door, y_door)
    Z_door = np.full_like(X_door, 1)
    ax.plot_surface(X_door, Y_door, Z_door, color='green', alpha=0.6, label="Door")

    # Bus handle (a small cuboid)
    x_handle = np.linspace(4.8, 5.2, 10)
    y_handle = np.linspace(2.4, 2.6, 10)
    z_handle = np.linspace(1.4, 1.6, 10)
    X_handle, Y_handle = np.meshgrid(x_handle, y_handle)
    Z_handle = np.full_like(X_handle, 1.5)
    ax.plot_surface(X_handle, Y_handle, Z_handle, color='silver', alpha=0.8, label="Handle")

# Function to interpolate fixture paths for smooth animation
def interpolate_path(start, end, steps=20):
    return list(zip(
        np.linspace(start[0], end[0], steps),
        np.linspace(start[1], end[1], steps),
        np.linspace(start[2], end[2], steps)
    ))

# Create interpolated paths for the working fixtures
interpolated_paths = {
    i: interpolate_path(fixture_paths[i][0], fixture_paths[i][1]) for i in range(3, num_fixtures)
}

# Create the 3D plot
fig = plt.figure(figsize=(16, 10))  # Increased figure width for better spacing
ax = fig.add_subplot(111, projection='3d')

# Create the full 3D bus model
create_full_bus(ax)

# Set plot limits and labels
ax.set_xlim(0, grid_size)
ax.set_ylim(0, grid_size)
ax.set_zlim(0, grid_size)
ax.set_xlabel('X Axis', fontsize=12)
ax.set_ylabel('Y Axis', fontsize=12)
ax.set_zlabel('Z Axis', fontsize=12)
ax.set_title("3D Bus with Door and Handle Fixing (3 Constant Fixtures, 2 Working Fixtures)", fontsize=16)

# Initialize fixture lines and annotations
colors = ["red", "green", "blue", "purple", "orange"]  # Colors for all fixtures
fixtures = [ax.plot([], [], [], marker="o", linestyle="-", color=colors[i], label=f"Fixture {i+1}")[0] for i in range(num_fixtures)]

# Add text annotations outside the 3D plot (left side)
fixture_annotations = [
    fig.text(0.02, 0.95 - i * 0.05, f"Fixture {i+1}: {'Working' if i >= 3 else 'Constant'}", 
             fontsize=12, color=colors[i], weight='bold')  # Added CSS-like styling
    for i in range(num_fixtures)
]

# Add coordinate displays outside the 3D plot (right side)
coordinate_annotations = [
    fig.text(0.75, 0.95 - i * 0.05, f"Fixture {i+1} Coords: ({start_positions[i][0]:.1f}, {start_positions[i][1]:.1f}, {start_positions[i][2]:.1f})", 
             fontsize=10, color=colors[i], weight='bold')  # Added CSS-like styling
    for i in range(num_fixtures)
]

# Add bus objects (door and handle) outside the 3D plot (right side, bottom)
bus_object_annotations = [
    fig.text(0.75, 0.25 - i * 0.05, f"{part}", 
             fontsize=10, color='black', weight='bold', 
             bbox=dict(facecolor=color, alpha=0.5))  # Added background color matching the object color
    for i, (part, color) in enumerate([
        ("Door", "green"),
        ("Handle", "silver")
    ])
]

# Add identification for each fixture (labels on the fixtures)
fixture_labels = [
    ax.text(start_positions[i][0], start_positions[i][1], start_positions[i][2], 
            f"Fixture {i+1}", fontsize=10, color=colors[i], weight='bold')  # Added CSS-like styling
    for i in range(num_fixtures)
]

# Animation function
def update(frame):
    for i in range(num_fixtures):
        if i >= 3:  # Only update working fixtures (Fixture 4 and Fixture 5)
            path = interpolated_paths[i]
            if frame < len(path):
                # Update fixture positions
                x_data = [start_positions[i][0], path[frame][0]]
                y_data = [start_positions[i][1], path[frame][1]]
                z_data = [start_positions[i][2], path[frame][2]]
                fixtures[i].set_data(x_data, y_data)
                fixtures[i].set_3d_properties(z_data)
                
                # Update fixture labels
                fixture_labels[i].set_position((path[frame][0], path[frame][1], path[frame][2]))
                
                # Update coordinate displays
                coordinate_annotations[i].set_text(f"Fixture {i+1} Coords: ({path[frame][0]:.1f}, {path[frame][1]:.1f}, {path[frame][2]:.1f})")
    return fixtures + fixture_labels

# Create animation
ani = animation.FuncAnimation(
    fig,
    update,
    frames=max(len(path) for path in interpolated_paths.values()),
    interval=100,  # Slower animation (100ms per frame)
    blit=True
)

# Adjust layout to ensure all content is visible
plt.tight_layout()

# Show the animation
plt.show()