import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.animation as animation
import final
# Define grid size
grid_size = 30
num_fixtures = 10  # Number of fixtures

# Define wing parts and their positions in 3D space
wing_parts = {
    "root": (5, 0, 5),  # Root of the wing (closest to the fuselage)
    "tip": (5, 25, 5),  # Tip of the wing
    "leading_edge": (3, 12.5, 5),  # Leading edge of the wing
    "trailing_edge": (7, 12.5, 5),  # Trailing edge of the wing
    "aileron_left": (6, 20, 5),  # Left aileron
    "aileron_right": (6, 5, 5),  # Right aileron
    "flap_left": (4, 18, 5),  # Left flap
    "flap_right": (4, 7, 5),  # Right flap
    "winglet_left": (5, 25, 7),  # Left winglet
    "winglet_right": (5, 0, 7)  # Right winglet
}

# Define starting positions for each fixture
start_positions = {
    0: (0, 0, 0),  # Fixture 1 starts here
    1: (0, grid_size, 0),  # Fixture 2 starts here
    2: (grid_size, 0, 0),  # Fixture 3 starts here
    3: (grid_size, grid_size, 0),  # Fixture 4 starts here
    4: (0, grid_size // 2, 0),  # Fixture 5 starts here
    5: (grid_size, grid_size // 2, 0),  # Fixture 6 starts here
    6: (grid_size // 2, 0, 0),  # Fixture 7 starts here
    7: (grid_size // 2, grid_size, 0),  # Fixture 8 starts here
    8: (0, grid_size // 4, 0),  # Fixture 9 starts here
    9: (grid_size, 3 * grid_size // 4, 0)  # Fixture 10 starts here
}

# Define paths for each fixture to fix the wing parts
fixture_paths = {
    0: [start_positions[0], wing_parts["root"]],  # Fixture 1 fixes the root
    1: [start_positions[1], wing_parts["tip"]],  # Fixture 2 fixes the tip
    2: [start_positions[2], wing_parts["leading_edge"]],  # Fixture 3 fixes the leading edge
    3: [start_positions[3], wing_parts["trailing_edge"]],  # Fixture 4 fixes the trailing edge
    4: [start_positions[4], wing_parts["aileron_left"]],  # Fixture 5 fixes the left aileron
    5: [start_positions[5], wing_parts["aileron_right"]],  # Fixture 6 fixes the right aileron
    6: [start_positions[6], wing_parts["flap_left"]],  # Fixture 7 fixes the left flap
    7: [start_positions[7], wing_parts["flap_right"]],  # Fixture 8 fixes the right flap
    8: [start_positions[8], wing_parts["winglet_left"]],  # Fixture 9 fixes the left winglet
    9: [start_positions[9], wing_parts["winglet_right"]]  # Fixture 10 fixes the right winglet
}

# Function to create a 3D wing model
def create_wing(ax):
    # Wing shape (NACA airfoil cross-section)
    def airfoil_shape(x):
        return 0.6 * (0.2969 * np.sqrt(x) - 0.1260 * x - 0.3516 * x**2 + 0.2843 * x**3 - 0.1015 * x**4)

    # Create wing surface
    y = np.linspace(0, 25, 100)  # Span of the wing
    x = np.linspace(0, 1, 50)  # Chord of the wing
    Y, X = np.meshgrid(y, x)
    Z_upper = airfoil_shape(X) * (1 - Y / 25)  # Tapered airfoil
    Z_lower = -airfoil_shape(X) * (1 - Y / 25)  # Tapered airfoil

    # Plot upper and lower surfaces of the wing
    ax.plot_surface(X + 5, Y, Z_upper + 5, color='lightgray', alpha=0.8, label="Wing Upper Surface")
    ax.plot_surface(X + 5, Y, Z_lower + 5, color='lightgray', alpha=0.8, label="Wing Lower Surface")

    # Add wing parts (root, tip, ailerons, flaps, winglets)
    for part, pos in wing_parts.items():
        ax.scatter([pos[0]], [pos[1]], [pos[2]], color='red', s=100, label=part)

# Function to interpolate fixture paths for smooth animation
def interpolate_path(start, end, steps=50):
    return list(zip(
        np.linspace(start[0], end[0], steps),
        np.linspace(start[1], end[1], steps),
        np.linspace(start[2], end[2], steps)
    ))

# Create interpolated paths for each fixture
interpolated_paths = {
    i: interpolate_path(fixture_paths[i][0], fixture_paths[i][1]) for i in range(num_fixtures)
}

# Create the 3D plot
fig = plt.figure(figsize=(20, 12))  # Increased figure size for better spacing
ax = fig.add_subplot(111, projection='3d')

# Create the 3D wing model
create_wing(ax)

# Set plot limits and labels
ax.set_xlim(0, grid_size)
ax.set_ylim(0, grid_size)
ax.set_zlim(0, grid_size)
ax.set_xlabel('X Axis', fontsize=12)
ax.set_ylabel('Y Axis', fontsize=12)
ax.set_zlabel('Z Axis', fontsize=12)
ax.set_title("3D Plane Wing with Fixture Movements", fontsize=16)

# Initialize fixture lines and annotations
colors = plt.cm.tab10.colors  # Use a colormap for 10 distinct colors
fixtures = [ax.plot([], [], [], marker="o", linestyle="-", color=colors[i], label=f"Fixture {i+1}")[0] for i in range(num_fixtures)]

# Add text annotations outside the 3D plot (left side)
fixture_annotations = [
    fig.text(0.02, 0.95 - i * 0.05, f"Fixture {i+1}: Moving to {list(wing_parts.keys())[i]}", 
             fontsize=10, color=colors[i], weight='bold')  # Added CSS-like styling
    for i in range(num_fixtures)
]

# Add coordinate displays outside the 3D plot (right side)
coordinate_annotations = [
    fig.text(0.75, 0.95 - i * 0.05, f"Fixture {i+1} Coords: ({start_positions[i][0]:.1f}, {start_positions[i][1]:.1f}, {start_positions[i][2]:.1f})", 
             fontsize=8, color=colors[i], weight='bold')  # Added CSS-like styling
    for i in range(num_fixtures)
]

# Add wing objects (root, tip, ailerons, flaps, winglets) outside the 3D plot (right side, bottom)
wing_object_annotations = [
    fig.text(0.75, 0.25 - i * 0.05, f"{part}", 
             fontsize=10, color='black', weight='bold', 
             bbox=dict(facecolor=colors[i], alpha=0.5))  # Added background color matching the object color
    for i, part in enumerate(wing_parts.keys())
]

# Add identification for each fixture (labels on the fixtures)
fixture_labels = [
    ax.text(start_positions[i][0], start_positions[i][1], start_positions[i][2], 
            f"Fixture {i+1}", fontsize=8, color=colors[i], weight='bold')  # Added CSS-like styling
    for i in range(num_fixtures)
]

# Animation function
def update(frame):
    for i in range(num_fixtures):
        path = interpolated_paths[i]
        if frame < len(path):
            # Update fixture positions
            x_data = [start_positions[i][0], path[frame][0]]
            y_data = [start_positions[i][1], path[frame][1]]
            z_data = [start_positions[i][2], path[frame][2]]
            fixtures[i].set_data(x_data, y_data)
            fixtures[i].set_3d_properties(z_data)
            
            # Update fixture labels
            fixture_labels[i].set_position((path[frame][0], path[frame][1], path[frame][2]))
            
            # Update coordinate displays
            coordinate_annotations[i].set_text(f"Fixture {i+1} Coords: ({path[frame][0]:.1f}, {path[frame][1]:.1f}, {path[frame][2]:.1f})")
    return fixtures + fixture_labels

# Create animation
ani = animation.FuncAnimation(
    fig,
    update,
    frames=max(len(path) for path in interpolated_paths.values()),
    interval=50,  # Faster animation (50ms per frame)
    blit=True
)

# Adjust layout to ensure all content is visible
plt.tight_layout()

# Show the animation
plt.show()