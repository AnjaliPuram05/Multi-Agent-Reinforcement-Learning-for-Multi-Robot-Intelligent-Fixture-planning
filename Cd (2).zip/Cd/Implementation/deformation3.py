import numpy as np

# Define bus parts (3D positions)
fan_parts = {
    "motor": (5, 5, 5),  # Motor position
    "blade1": (5, 7, 5),  # Blade 1 position
    "blade2": (3, 5, 5),  # Blade 2 position
    "blade3": (7, 5, 5),  # Blade 3 position
    "base": (5, 5, 0)  # Base position
}

class FixtureDesign3DEnv:
    def __init__(self):
        self.length = 10
        self.width = 10
        self.height = 5
        self.grid_size = 10
        self.agents = 5
        self.pressure = 100
        self.flexural_rigidity = 5000
        self.parts_list = list(fan_parts.values())
        self.state = None

    def reset(self):
        # Randomize initial positions near their target parts
        self.state = []
        for part in self.parts_list:
            noise = np.random.uniform(-1.0, 1.0, size=3)  # small random noise
            init_pos = np.clip(np.array(part) + noise, 0, 10)
            self.state.append(init_pos)
        return self.state

    def step(self, actions):
        deformations = []
        rewards = []
        for agent_idx, action in enumerate(actions):
            target_part = self.parts_list[agent_idx]
            deformation = self.calculate_deformation(action, target_part)
            reward = 100 - deformation  # Higher reward for lower deformation
            deformations.append(deformation)
            rewards.append(reward)
        return deformations, rewards

    def calculate_deformation(self, fixture_pos, target_pos):
        """Deformation is based on distance to the correct part, assuming 3D structure"""
        distance = np.linalg.norm(np.array(fixture_pos) - np.array(target_pos))
        
        # Simulate realistic small deformations using physical parameters
        deformation = (self.pressure * distance ** 4) / (64 * self.flexural_rigidity)
        
        # Force deformation to be precise to decimals
        deformation = np.round(deformation, 5)
        return deformation

    def smart_actions(self):
        """Move each agent closer to their assigned part (simulate learning behavior)"""
        actions = []
        for agent_idx in range(self.agents):
            target = self.parts_list[agent_idx]
            noise = np.random.normal(0, 0.2, size=3)  # very small random noise
            smart_pos = np.clip(np.array(target) + noise, 0, 10)
            actions.append(smart_pos)
        return actions

# ---------------------------------------------------------------
# Train Agents
# ---------------------------------------------------------------
env = FixtureDesign3DEnv()
episodes = 100
patience = 10
deformation_history = {i: [] for i in range(env.agents)}

print("Episode\tAgent\tPosition\t\tDeformation\tReward")
print("-" * 70)

for episode in range(episodes):
    actions = env.smart_actions() if episode >= 40 else env.reset()
    x=[]
    deformations, rewards = env.step(actions)

    for agent_id in range(env.agents):
        pos = actions[agent_id]
        print(f"{episode+1:02d}\t{agent_id}\t{pos.round(2)}\t{deformations[agent_id]:.5f}\t\t{rewards[agent_id]:.4f}")

        # Update history
        deformation_history[agent_id].append(deformations[agent_id])
        if len(deformation_history[agent_id]) > patience:
            deformation_history[agent_id].pop(0)
        if episode == episodes-1:
            x.append(pos.round(3))
    print("-" * 70)
   
    # Early stopping if last 10 deformations are stable
    if episode >= patience:
        no_change = all(
            max(hist) - min(hist) < 1e-4  # Tighter convergence
            for hist in deformation_history.values()
        )
        avg_deformation = np.mean([hist[-1] for hist in deformation_history.values()])
        
        if no_change and (1.0 <= avg_deformation <= 2.0):
            print(f"\n✅ Early stopping at episode {episode+1} — deformation stabilized between 1-2 units.\n")
            break
print(' the final positions are:')
print(x)
