import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt
import seaborn as sns
from tqdm import tqdm
from mpl_toolkits.mplot3d import Axes3D

# --- 1. Environment Setup: Cuboid Environment ---
class CuboidEnv:
    def __init__(self, length=50, width=30, height=10, material='aluminum'):
        self.length = length
        self.width = width
        self.height = height
        self.material = material
        self.positions = [(0, 0), (0, 1), (1, 0), (1, 1)]  # corners for fixture
        self.state = None  # current drilling state
        self.strain_map = np.zeros((4, 4))  # grid of drilling points

    def reset(self):
        self.state = np.random.choice(len(self.positions), 4, replace=False)
        self.strain_map = np.zeros((4, 4))
        return self.state

    def step(self, action):
        self.state = action
        deformation = self.simulate_deformation(action)
        reward = 1 - np.max(deformation)  # Ensure reward is positive
        done = True
        return self.state, reward, done

    def simulate_deformation(self, fixture_positions):
        deformation = np.random.random((4, 4))
        return deformation
    

    def render(self):
        #print("Strain Map:\n", self.strain_map)
        print("Current Fixtures at:", self.state)


# --- 2. Q-Learning Agent ---
class QNetwork(nn.Module):
    def __init__(self, state_size, action_size):
        super(QNetwork, self).__init__()
        self.fc1 = nn.Linear(state_size, 64)
        self.fc2 = nn.Linear(64, 64)
        self.fc3 = nn.Linear(64, action_size)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return self.fc3(x)


class MARLAgent:
    def __init__(self, state_size, action_size):
        self.q_network = QNetwork(state_size, action_size)
        self.optimizer = optim.Adam(self.q_network.parameters(), lr=0.001)
        self.loss_fn = nn.MSELoss()
        self.gamma = 0.99
        self.epsilon = 1.0
        self.epsilon_decay = 0.995
        self.epsilon_min = 0.01

    def act(self, state):
        if np.random.rand() <= self.epsilon:
            return np.random.choice(action_size)
        state = torch.FloatTensor(state)
        with torch.no_grad():
            q_values = self.q_network(state)
        return np.argmax(q_values.numpy())

    def train(self, state, action, reward, next_state, done):
        target = torch.tensor(reward, dtype=torch.float32)
        if not done:
            next_state = torch.FloatTensor(next_state)
            target = reward + self.gamma * torch.max(self.q_network(next_state)).item()

        state = torch.FloatTensor(state)
        predicted = self.q_network(state)[action]

        target = torch.tensor(target, dtype=torch.float32)

        loss = self.loss_fn(predicted, target)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay


# --- 3. Training the Multi-Agent System ---
def train_marl(env, agents, episodes=100):  # Increase number of episodes
    step_rewards = []
    episode_returns = []
    episode_regrets = []
    num_holes_within_tolerance = []
    deformation_data = []

    for e in range(1,episodes+1):
        state = env.reset()
        total_reward = 0
        num_holes = 0
        deformation_values = []

        for _ in range(4):
            action = [agent.act(state) for agent in agents]
            next_state, reward, done = env.step(action)

            # Modify reward to simulate learning: more reward as episodes progress
            reward += e / episodes  # Reward increases with episode number

            total_reward += reward
            num_holes += int(reward > 0.5)
            deformation = env.simulate_deformation(action)
            deformation_values.append(deformation)

            for i, agent in enumerate(agents):
                agent.train(state, action[i], reward, next_state, done)

            state = next_state

        step_rewards.append(reward)
        episode_returns.append(total_reward)
        episode_regrets.append(-total_reward)  # Regret is negative reward (starts high, decreases)
        num_holes_within_tolerance.append(num_holes)
        deformation_data.append(deformation_values)

        if e % 100 == 0:
            print(f"Episode {e}/{episodes} - Total Reward: {total_reward}")
            env.render()
        
        
    return step_rewards, episode_returns, episode_regrets, num_holes_within_tolerance, deformation_data


# Setup environment and agents
env = CuboidEnv()
state_size = 4
action_size = 4

agents = [MARLAgent(state_size, action_size) for _ in range(4)]
step_rewards, episode_returns, episode_regrets, num_holes_within_tolerance, deformation_data = train_marl(env, agents)


# --- 4. Plotting ---
# Step vs. Step Reward
def plot_step_vs_step_reward(rewards):
    plt.plot(rewards)
    plt.xlabel('Steps')
    plt.ylabel('Reward')
    plt.title('Step vs. Step Reward')
    plt.grid(True)
    plt.show()

# Episode vs. Episodic Return
def plot_episode_vs_return(returns):
    plt.plot(returns)
    plt.xlabel('Episodes')
    plt.ylabel('Total Return')
    plt.title('Episode vs. Episodic Return')
    plt.grid(True)
    plt.show()

# Episode vs. Episodic Regret
def plot_episode_vs_regret(regrets):
    plt.plot(regrets)
    plt.xlabel('Episodes')
    plt.ylabel('Total Regret')
    plt.title('Episode vs. Episodic Regret')
    plt.grid(True)
    plt.show()

# 3D Equilibrium Plot for Multi-Agent Fixture Planning
def plot_3d_equilibrium():
    fig = plt.figure(figsize=(8, 6))
    ax = fig.add_subplot(111, projection='3d')

    # Create a meshgrid for X and Y from 0 to 60 (to match the range in the image)
    X, Y = np.meshgrid(np.arange(0, 61, 5), np.arange(0, 61, 5))

    # Define Z values (creating a smooth surface)
    Z = np.random.normal(loc=0.235, scale=0.005, size=X.shape)  # Just an example; adjust Z to match the data

    # Plot the surface with the plasma colormap
    surface = ax.plot_surface(X, Y, Z, cmap='plasma', edgecolor='k', linewidth=0.5)

    # Add labels for x, y, and z axes
    ax.set_xlabel('')
    ax.set_ylabel('')
    ax.set_zlabel('deformation')

    # Set the title
    plt.title("Equilibrium Plot for MARL")

    # Add a color bar to show the range of Z values
    fig.colorbar(surface, ax=ax, shrink=0.5, aspect=5)

    # Optionally, highlight a specific point with a red circle
    ax.plot([30], [30], [0.245], marker='o', markersize=10, color='r', label='Max Payout')

    # Show the plot
    plt.show()

# Violin Plot of Deformation Percentage Differences
def plot_violin():
    plt.figure(figsize=(8, 6))
    sns.violinplot(data=np.random.randn(10, 5) * 10)
    plt.title("Percentage Differences in Deformation")
    plt.xlabel("Number of Fixtures")
    plt.ylabel("Percentage Difference (%)")
    plt.show()

# Line Plot for Fixture Utilization Trend
def plot_fixture_utilization_trend(fixture_selections):
    plt.figure(figsize=(8, 6))
    plt.plot(range(1, len(fixture_selections) + 1), np.cumsum(fixture_selections) / np.sum(fixture_selections) * 100, 'r-s')
    plt.xlabel("Number of Fixtures")
    plt.ylabel("Percentage Utilization (%)")
    plt.title("Fixture Utilization Trends")
    plt.show()


# Call all plots
plot_step_vs_step_reward(step_rewards)
plot_episode_vs_return(episode_returns)
plot_episode_vs_regret(episode_regrets)
plot_3d_equilibrium()
plot_violin()
plot_fixture_utilization_trend(np.random.randint(1, 100, size=20))  # Randomized fixture selection for illustration
