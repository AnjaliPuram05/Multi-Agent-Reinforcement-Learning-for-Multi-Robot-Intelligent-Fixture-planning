import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.animation as animation
import deformation3
import final
sam=np.array(deformation3.x)
print(sam)
grid_size = 10
num_fixtures = 5  # Number of fixtures
t1=tuple(sam[0])
t2=tuple(sam[1])
t3=tuple(sam[2])
t4=tuple(sam[3])
t5=tuple(sam[4])
# Define grid size
grid_size = 10
num_fixtures = 4  # Number of fixtures

# Define fan parts and their positions in 3D space
#fan_parts = {
 #   "motor": t1,  # Motor position
  #  "blade1": t2,  # Blade 1 position
  #  "blade2": t3,  # Blade 2 position
  ##  "blade3": t4,  # Blade 3 position
   # "base": t5  # Base position
#}

fan_parts = {
    "motor": (5, 5, 5),  # Motor position
    "blade1": (5, 7, 5),  # Blade 1 position
    "blade2": (3, 5, 5),  # Blade 2 position
    "blade3": (7, 5, 5),  # Blade 3 position
    "base": (5, 5, 0)  # Base position
}

# Define starting positions for each fixture
start_positions = {
    0: (0, 0, 0),  # Fixture 1 starts here
    1: (0, 10, 0),  # Fixture 2 starts here
    2: (10, 0, 0),  # Fixture 3 starts here
    3: (10, 10, 0)  # Fixture 4 starts here
}

# Define paths for each fixture to fix the fan parts
fixture_paths = {
    0: [start_positions[0], fan_parts["motor"]],  # Fixture 1 fixes motor
    1: [start_positions[1], fan_parts["blade1"]],  # Fixture 2 fixes blade 1
    2: [start_positions[2], fan_parts["blade2"]],  # Fixture 3 fixes blade 2
    3: [start_positions[3], fan_parts["blade3"]]  # Fixture 4 fixes blade 3
}

# Function to create a full 3D fan model
def create_full_fan(ax):
    # Fan motor housing (a cylinder)
    u = np.linspace(0, 2 * np.pi, 30)
    v = np.linspace(0, 1, 10)
    U, V = np.meshgrid(u, v)
    X_motor = fan_parts["motor"][0] + 0.5 * np.outer(np.cos(U), np.ones_like(V))
    Y_motor = fan_parts["motor"][1] + 0.5 * np.outer(np.sin(U), np.ones_like(V))
    Z_motor = fan_parts["motor"][2] + 1.5 * np.outer(np.ones(np.size(U)), V)
    ax.plot_surface(X_motor, Y_motor, Z_motor, color='gray', alpha=0.8, label="Motor Housing")

    # Fan blades (flat rectangles for better visualization)
    blade_positions = [fan_parts["blade1"], fan_parts["blade2"], fan_parts["blade3"]]
    for blade in blade_positions:
        x_blade = np.linspace(blade[0] - 0.5, blade[0] + 0.5, 10)
        y_blade = np.linspace(blade[1] - 0.1, blade[1] + 0.1, 10)
        z_blade = np.linspace(blade[2] - 0.1, blade[2] + 0.1, 10)
        X_blade, Y_blade = np.meshgrid(x_blade, y_blade)
        Z_blade = np.full_like(X_blade, blade[2])
        ax.plot_surface(X_blade, Y_blade, Z_blade, color='blue', alpha=0.6, label="Blade")

    # Fan base (a pedestal)
    u = np.linspace(0, 2 * np.pi, 30)
    v = np.linspace(0, 1, 10)
    U, V = np.meshgrid(u, v)
    X_base = fan_parts["base"][0] + 1 * np.outer(np.cos(U), np.ones_like(V))
    Y_base = fan_parts["base"][1] + 1 * np.outer(np.sin(U), np.ones_like(V))
    Z_base = fan_parts["base"][2] + 2 * np.outer(np.ones(np.size(U)), V)
    ax.plot_surface(X_base, Y_base, Z_base, color='black', alpha=0.8, label="Base")

# Function to interpolate fixture paths for smooth animation
def interpolate_path(start, end, steps=20):
    return list(zip(
        np.linspace(start[0], end[0], steps),
        np.linspace(start[1], end[1], steps),
        np.linspace(start[2], end[2], steps)
    ))

# Create interpolated paths for each fixture
interpolated_paths = {
    i: interpolate_path(fixture_paths[i][0], fixture_paths[i][1]) for i in range(num_fixtures)
}

# Create the 3D plot
fig = plt.figure(figsize=(16, 10))  # Increased figure width for better spacing
ax = fig.add_subplot(111, projection='3d')

# Create the full 3D fan model
create_full_fan(ax)

# Set plot limits and labels
ax.set_xlim(0, grid_size)
ax.set_ylim(0, grid_size)
ax.set_zlim(0, grid_size)
ax.set_xlabel('X Axis', fontsize=12)
ax.set_ylabel('Y Axis', fontsize=12)
ax.set_zlabel('Z Axis', fontsize=12)
ax.set_title("3D Fan with Fixture Movements", fontsize=16)

# Initialize fixture lines and annotations
colors = ["red", "green", "blue", "purple"]
fixtures = [ax.plot([], [], [], marker="o", linestyle="-", color=colors[i], label=f"Fixture {i+1}")[0] for i in range(num_fixtures)]

# Add text annotations outside the 3D plot (left side)
fixture_annotations = [
    fig.text(0.02, 0.95 - i * 0.05, f"Fixture {i+1}: Moving to {list(fan_parts.keys())[i]}", 
             fontsize=12, color=colors[i], weight='bold')  # Added CSS-like styling
    for i in range(num_fixtures)
]

# Add coordinate displays outside the 3D plot (right side)
coordinate_annotations = [
    fig.text(0.75, 0.95 - i * 0.05, f"Fixture {i+1} Coords: ({start_positions[i][0]:.1f}, {start_positions[i][1]:.1f}, {start_positions[i][2]:.1f})", 
             fontsize=10, color=colors[i], weight='bold')  # Added CSS-like styling
    for i in range(num_fixtures)
]

# Add fan objects (motor, blades, base) outside the 3D plot (right side, bottom)
fan_object_annotations = [
    fig.text(0.75, 0.25 - i * 0.05, f"{part}", 
             fontsize=10, color='black', weight='bold', 
             bbox=dict(facecolor=color, alpha=0.5))  # Added background color matching the object color
    for i, (part, color) in enumerate([
        ("Motor Housing", "gray"),
        ("Blades", "blue"),
        ("Base", "black")
    ])
]

# Add identification for each fixture (labels on the fixtures)
fixture_labels = [
    ax.text(start_positions[i][0], start_positions[i][1], start_positions[i][2], 
            f"Fixture {i+1}", fontsize=10, color=colors[i], weight='bold')  # Added CSS-like styling
    for i in range(num_fixtures)
]

# Animation function
def update(frame):
    for i in range(num_fixtures):
        path = interpolated_paths[i]
        if frame < len(path):
            # Update fixture positions
            x_data = [start_positions[i][0], path[frame][0]]
            y_data = [start_positions[i][1], path[frame][1]]
            z_data = [start_positions[i][2], path[frame][2]]
            fixtures[i].set_data(x_data, y_data)
            fixtures[i].set_3d_properties(z_data)
            
            # Update fixture labels
            fixture_labels[i].set_position((path[frame][0], path[frame][1], path[frame][2]))
            
            # Update coordinate displays
            coordinate_annotations[i].set_text(f"Fixture {i+1} Coords: ({path[frame][0]:.1f}, {path[frame][1]:.1f}, {path[frame][2]:.1f})")
    return fixtures + fixture_labels

# Create animation
ani = animation.FuncAnimation(
    fig,
    update,
    frames=max(len(path) for path in interpolated_paths.values()),
    interval=100,  # Slower animation (100ms per frame)
    blit=True
)

# Adjust layout to ensure all content is visible
plt.tight_layout()

# Show the animation
plt.show()