import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.animation as animation
import deformation2
#import final
# Define grid size
sam=np.array(deformation2.x)
print(sam)
grid_size = 10
num_fixtures = 5  # Number of fixtures
t1=tuple(sam[0])
t2=tuple(sam[1])
t3=tuple(sam[2])
t4=tuple(sam[3])
t5=tuple(sam[4])
# Define bus parts and their positions in 3D space
bus_parts = {
    "left_mirror": t1,  # Left mirror position 1
    "right_mirror": t2,  # Right mirror position 2
    "front_left_wheel": t4,  # Front left wheel position 3
    "front_right_wheel": t3,  # Front right wheel position  4
    "rear_left_wheel": (2, 3, 0),  # Rear left wheel position
    "rear_right_wheel": (2, 7, 0),  # Rear right wheel position
    "roof": t5  # Roof position  5
}

#bus_parts = {
#    "left_mirror": (2, 2, 1.5),
#    "right_mirror": (2, 8, 1.5),
#    "front_left_wheel": (8, 3, 0),
#    "front_right_wheel": (8, 7, 0),
#    "roof": (5, 5, 2.5)
#}

# Define starting positions for each fixture
start_positions = {
    0: (0, 0, 0),  # Fixture 1 starts here
    1: (0, 10, 0),  # Fixture 2 starts here
    2: (10, 0, 0),  # Fixture 3 starts here
    3: (10, 10, 0),  # Fixture 4 starts here
    4: (5, 5, 5)  # Fixture 5 starts here
}

# Define paths for each fixture to fix the bus parts
fixture_paths = {
    0: [start_positions[0], bus_parts["left_mirror"]],  # Fixture 1 fixes left mirror
    1: [start_positions[1], bus_parts["right_mirror"]],  # Fixture 2 fixes right mirror
    2: [start_positions[2], bus_parts["front_left_wheel"]],  # Fixture 3 fixes front left wheel
    3: [start_positions[3], bus_parts["front_right_wheel"]],  # Fixture 4 fixes front right wheel
    4: [start_positions[4], bus_parts["roof"]]  # Fixture 5 fixes roof
}

# Function to create a full 3D bus model
def create_full_bus(ax):
    # Bus body (a rectangular cuboid)
    x = np.linspace(2, 8, 10)
    y = np.linspace(3, 7, 10)
    z = np.linspace(0, 2, 10)
    X, Y = np.meshgrid(x, y)
    Z = np.zeros_like(X)
    ax.plot_surface(X, Y, Z, color='orange', alpha=0.6, label="Bus Body")  # Bus body color: orange

    # Bus roof (a smaller rectangular cuboid)
    x_roof = np.linspace(3, 7, 10)
    y_roof = np.linspace(4, 6, 10)
    z_roof = np.linspace(2, 3, 10)
    X_roof, Y_roof = np.meshgrid(x_roof, y_roof)
    Z_roof = np.full_like(X_roof, 2)
    ax.plot_surface(X_roof, Y_roof, Z_roof, color='gray', alpha=0.6, label="Bus Roof")  # Bus roof color: gray

    # Bus wheels (cylinders represented as circles)
    wheel_positions = [
        bus_parts["front_left_wheel"], bus_parts["front_right_wheel"],
        bus_parts["rear_left_wheel"], bus_parts["rear_right_wheel"]
    ]
    for wheel in wheel_positions:
        u = np.linspace(0, 2 * np.pi, 30)
        v = np.linspace(0, 0.5, 10)
        U, V = np.meshgrid(u, v)
        X_wheel = wheel[0] + 0.5 * np.cos(U)
        Y_wheel = wheel[1] + 0.5 * np.sin(U)
        Z_wheel = wheel[2] + V
        ax.plot_surface(X_wheel, Y_wheel, Z_wheel, color='black', alpha=0.8, label="Wheel")  # Wheel color: black

    # Bus mirrors (small cuboids)
    mirror_positions = [bus_parts["left_mirror"], bus_parts["right_mirror"]]
    for mirror in mirror_positions:
        x_mirror = np.linspace(mirror[0] - 0.2, mirror[0] + 0.2, 10)
        y_mirror = np.linspace(mirror[1] - 0.2, mirror[1] + 0.2, 10)
        z_mirror = np.linspace(mirror[2] - 0.2, mirror[2] + 0.2, 10)
        X_mirror, Y_mirror = np.meshgrid(x_mirror, y_mirror)
        Z_mirror = np.full_like(X_mirror, mirror[2])
        ax.plot_surface(X_mirror, Y_mirror, Z_mirror, color='silver', alpha=0.8, label="Mirror")  # Mirror color: silver

# Function to interpolate fixture paths for smooth animation
def interpolate_path(start, end, steps=20):
    return list(zip(
        np.linspace(start[0], end[0], steps),
        np.linspace(start[1], end[1], steps),
        np.linspace(start[2], end[2], steps)
    ))

# Create interpolated paths for each fixture
interpolated_paths = {
    i: interpolate_path(fixture_paths[i][0], fixture_paths[i][1]) for i in range(num_fixtures)
}

# Create the 3D plot
fig = plt.figure(figsize=(16, 10))  # Increased figure width for better spacing
ax = fig.add_subplot(111, projection='3d')

# Create the full 3D bus model
create_full_bus(ax)

# Set plot limits and labels
ax.set_xlim(0, grid_size)
ax.set_ylim(0, grid_size)
ax.set_zlim(0, grid_size)
ax.set_xlabel('X Axis', fontsize=12)
ax.set_ylabel('Y Axis', fontsize=12)
ax.set_zlabel('Z Axis', fontsize=12)
ax.set_title("3D Bus with Fixture Movements", fontsize=16)

# Initialize fixture lines and annotations
colors = ["red", "green", "blue", "purple", "orange"]
fixtures = [ax.plot([], [], [], marker="o", linestyle="-", color=colors[i], label=f"Fixture {i+1}")[0] for i in range(num_fixtures)]

# Add text annotations outside the 3D plot (left side)
fixture_annotations = [
    fig.text(0.02, 0.95 - i * 0.05, f"Fixture {i+1}: Moving to {list(bus_parts.keys())[i]}", 
             fontsize=12, color=colors[i], weight='bold')  # Added CSS-like styling
    for i in range(num_fixtures)
]

# Add coordinate displays outside the 3D plot (right side)
coordinate_annotations = [
    fig.text(0.75, 0.95 - i * 0.05, f"Fixture {i+1} Coords: ({start_positions[i][0]:.1f}, {start_positions[i][1]:.1f}, {start_positions[i][2]:.1f})", 
             fontsize=10, color=colors[i], weight='bold')  # Added CSS-like styling
    for i in range(num_fixtures)
]

# Add bus objects (wheels, mirrors, body, roof) outside the 3D plot (right side, bottom)
bus_object_annotations = [
    fig.text(0.75, 0.25 - i * 0.05, f"{part}", 
             fontsize=10, color='black', weight='bold', 
             bbox=dict(facecolor=color, alpha=0.5))  # Added background color matching the object color
    for i, (part, color) in enumerate([
        ("Bus Body", "orange"),
        ("Bus Roof", "gray"),
        ("Wheels", "black"),
        ("Mirrors", "silver")
    ])
]

# Add identification for each fixture (labels on the fixtures)
fixture_labels = [
    ax.text(start_positions[i][0], start_positions[i][1], start_positions[i][2], 
            f"Fixture {i+1}", fontsize=10, color=colors[i], weight='bold')  # Added CSS-like styling
    for i in range(num_fixtures)
]

# Animation function
def update(frame):
    for i in range(num_fixtures):
        path = interpolated_paths[i]
        if frame < len(path):
            # Update fixture positions
            x_data = [start_positions[i][0], path[frame][0]]
            y_data = [start_positions[i][1], path[frame][1]]
            z_data = [start_positions[i][2], path[frame][2]]
            fixtures[i].set_data(x_data, y_data)
            fixtures[i].set_3d_properties(z_data)
            
            # Update fixture labels
            fixture_labels[i].set_position((path[frame][0], path[frame][1], path[frame][2]))
            
            # Update coordinate displays
            coordinate_annotations[i].set_text(f"Fixture {i+1} Coords: ({path[frame][0]:.1f}, {path[frame][1]:.1f}, {path[frame][2]:.1f})")
    return fixtures + fixture_labels

# Create animation
ani = animation.FuncAnimation(
    fig,
    update,
    frames=max(len(path) for path in interpolated_paths.values()),
    interval=100,  # Slower animation (100ms per frame)
    blit=True
)

# Adjust layout to ensure all content is visible
plt.tight_layout()

# Show the animation
plt.show()